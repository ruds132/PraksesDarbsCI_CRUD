<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\PostModel;
use Config\Validation;

class PostController extends BaseController {
    public function index() {
        return view('index');
    }
    public function getCategories()
    {
        $postModel = new PostModel();
        $categories = $postModel->getCategoryNames();
    
        $formattedCategories = [];
        foreach ($categories as $category) {
            
            $formattedCategories[] = [
                'id' => $category['id'],
                'name' => $category['name']
            ];
        }    
        return $this->response->setJSON($formattedCategories);
    }

    // handle add new post ajax request
    public function add() {
        $imageArray = $this->request->getFileMultiple('titleimage');
        $imagesToDelete = $this->request->getFileMultiple('addImagesToDelete');
        $addImagesNameChange = json_decode($this->request->getPost('addImageFileName'));
        log_message("info", print_r($addImagesNameChange, true));
        usort($addImagesNameChange, function($a, $b) {
            return $a->id <=> $b->id;
        });
        log_message("info", print_r($addImagesNameChange, true));
            $originalNameArray = [];
            $originalConvertedArray = [];
            $randomNameArray = [];
            $finalJsonArray = [];
            $filteredAddImageArray = [];
        if(!empty($imagesToDelete)){
            $toGetDeletedNames = array_map(function($file) {
                return $file->getName();
            }, $imagesToDelete);
            
            $filteredAddImageArray = array_values(array_filter($imageArray, function($file) use ($toGetDeletedNames) {
                return !in_array($file->getName(), $toGetDeletedNames);
            }));
            $imageArray = $filteredAddImageArray;
        }
        for($i = 0; $i < sizeof($imageArray); $i++){
            $originalNameArray[$i] = $imageArray[$i]->getClientName();
            $originalConvertedArray[$i] = mb_url_title($originalNameArray[$i]);
            $randomNameArray[$i] = $imageArray[$i]->getRandomName();

            $finalJsonArray[$i] = [
                "filename" => $originalConvertedArray[$i] . '-' . $randomNameArray[$i],
                "originalfilename" => $originalNameArray[$i],
                "filetitle" => $originalNameArray[$i]
            ];

        }
        foreach ($addImagesNameChange as $item) {
            if (isset($finalJsonArray[$item->id])) {
                $finalJsonArray[$item->id]['filetitle'] = $item->nameChange;
            }
        }
        for($i = 0; $i < sizeof($finalJsonArray); $i++){
            $imageArray[$i]->move('uploads/avatar', $finalJsonArray[$i]["filename"]);
        }
        

        $category = json_encode($this->request->getPost('category'));
        $fileName = json_encode($finalJsonArray);
        $data = [
            'title' => $this->request->getPost('title'),
            'category_id' => $this->request->getPost('category'),
            'body' => $this->request->getPost('body'),
            'tags' => json_encode($this->request->getPost('addtag[]')),
            'image' => $fileName,
            'created_at' => date('Y-m-d H:i:s')
        ];

        $postModel = new PostModel();
        $postModel->save($data);
        return $this->response->setJSON([
            'error' => false,
            'message' => 'Successfully added new post!'
        ]);
    }
    public function tags() {
        $db = \Config\Database::connect();
        $query = $db->query('SELECT distinct tagini FROM public.posts, jsonb_array_elements(tags) AS tagini');

        $result = $query->getResultArray();
        $allTags = array_column($result, 'tagini');
        if(empty($result)){
            return $this->response->setJSON([
                'error' => true,
                'message' => 'viss slikti'
            ]);
        } else {
            return $this->response->setJSON([
                'error' => false,
                'message' => $allTags
            ]);
        }
    }
    // handle fetch all posts ajax request
    public function fetch($tags) {
        $postModel = new PostModel();
        $posts = $postModel->findAll();
        log_message("info", print_r($posts, true));
        $tagsArray = explode(',', $tags);
        //log_message("info", $tagsArray[0]);

        if($tagsArray[0] != 'tuksums'){
            $tagsJson = json_encode($tagsArray);
            log_message("info", "not sigma");
            $db = \Config\Database::connect();
            $query = $db->query('SELECT * 
                FROM public.posts 
                WHERE tags @> ?::jsonb
            ', [$tagsJson]);
            $posts = $query->getResultArray();
            log_message("info", print_r($posts,true));


        }
        $data = '';

        if ($posts) {
            foreach ($posts as $post) {
                $fileHTML = '';
                $postimage = json_decode($post['image']);
                $postCategoryName = '';
                $postCategory = $postModel->getCategoryNames();
                //log_message("info", print_r($postCategory, true));
                foreach($postCategory as $category){
                    //log_message("info", print_r($category['name'], true));
                    if($category['id'] == json_decode($post['category_id'])){
                        $postCategoryName = $category['name'];
                    }
                }
                for($i = 0;sizeof($postimage) > $i; $i++){
                    $filenamee = $postimage[$i]->filename;
                    $fileHTML .= '<img src="uploads/avatar/' . $filenamee . '" class="img-fluid card-img-top">';
                }
                $postid = $post['id'];

                $data .= '<div class="col-md-4">
                <div class="card mb-3 shadow-sm">
                  <a href="#" id="' . $post['id'] . '" data-bs-toggle="modal" data-bs-target="#detail_post_modal" class="post_detail_btn">' . $fileHTML . '</a>
                  <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                      <div class="card-title fs-5 fw-bold">' . $post['title'] . '</div>
                      <div class="badge bg-dark">' . $postCategoryName . '</div>
                    </div>
                    <p>
                      ' . substr($post['body'], 0, 80) . '...
                    </p>
                  </div>
                  <div class="card-footer d-flex justify-content-between align-items-center">
                    <div class="fst-italic">' . date('d F Y', strtotime($post['created_at'])) . '</div>
                    <div>
                      <a href="#" id="' . $post['id'] . '" data-bs-toggle="modal" data-bs-target="#edit_post_modal" class="btn btn-success btn-sm post_edit_btn">Edit</a>

                      <a href="#" id="' . $post['id'] . '" class="btn btn-danger btn-sm post_delete_btn">Delete</a>
                    </div>
                  </div>
                </div>
              </div>';
            }
            return $this->response->setJSON([
                'error' => false,
                'message' => $data
            ]);
        } else {
            return $this->response->setJSON([
                'error' => false,
                'message' => '<div class="text-secondary text-center fw-bold my-5">No posts found in the database!</div>'
            ]);
        }
    }
    

    // handle edit post ajax request
    public function edit($id = null) {
        $postModel = new PostModel();
        $post = $postModel->find($id);
        $categories = $postModel->getCategoryNames();
        $formattedCategories = [];
        foreach ($categories as $category) {
            
            $formattedCategories[] = [
                'id' => $category['id'],
                'name' => $category['name']
            ];
        }    
        return $this->response->setJSON([
            'error' => false,
            'message' => [
                'post' => $post,
                'categories' => $formattedCategories
            ]
        ]);
    }
    // handle update post ajax request
    public function update() {
        log_message("info", "\nupdate start\n");
        $id = $this->request->getPost('id');
        $postModel = new PostModel();
        $post = $postModel->find($id);
        $oldImagesArray = json_decode($post['image'], true);
        $imageArray = $this->request->getFileMultiple('editimage');
        $replacementFileNames = json_decode($this->request->getPost('fileNames'));
        $toGetDeleted = $this->request->getFileMultiple('editToDelete');

        $originalNameArray = [];
        $originalConvertedArray = [];
        $randomNameArray = [];
        $fileExtensionArray = [];
        $newImagesArray = [];
        $filteredImageArray = [];

        if(!empty($toGetDeleted)){
            $toGetDeletedNames = array_map(function($file) {
                return $file->getName();
            }, $toGetDeleted);
            
            $filteredImageArray = array_values(array_filter($imageArray, function($file) use ($toGetDeletedNames) {
                return !in_array($file->getName(), $toGetDeletedNames);
            }));
            $imageArray = $filteredImageArray;
        }

        if (!empty($imageArray)) {
            for($i = 0; $i < sizeof($imageArray); $i++){
                
                $originalNameArray[$i] = $imageArray[$i]->getClientName();
                $originalConvertedArray[$i] = mb_url_title($originalNameArray[$i]);
                $randomNameArray[$i] = $imageArray[$i]->getRandomName();

                $newImagesArray[$i] = [
                    "filename" => $originalConvertedArray[$i] . '-' . $randomNameArray[$i],
                    "originalfilename" => $originalNameArray[$i],
                    "filetitle" => $originalNameArray[$i]
                ];
            }
            for($i = 0; $i < sizeof($newImagesArray); $i++){
                $imageArray[$i]->move('uploads/avatar', $newImagesArray[$i]["filename"]);
            }
        }
        $finalImagesArray = array_merge($oldImagesArray, $newImagesArray);
        if(!empty($replacementFileNames)){
            foreach($replacementFileNames as $replacement){
                $arrid = $replacement->id;
                $name = $replacement->nameChange;

                if (isset($finalImagesArray[$arrid])) {
                    $finalImagesArray[$arrid]['filetitle'] = $name;
                }
            }
        }
        $fileName = json_encode($finalImagesArray);
        log_message("info", print_r(json_encode($this->request->getPost('tag')), true));
        $tags =  json_encode($this->request->getPost('tag'));
        if($tags == null){
            $tags = '[""]';
        }
        $data = [
            'title' => $this->request->getPost('title'),
            'category_id' => json_encode($this->request->getPost('category')),
            'body' => $this->request->getPost('body'),
            'tags' => json_encode($this->request->getPost('tag')),
            'image' => $fileName,
            'updated_at' => date('Y-m-d H:i:s')
        ];
    
        $postModel->update($id, $data);
    
        return $this->response->setJSON([
            'error' => false,
            'message' => 'Successfully updated post!',
            'data' => $data
        ]);
    }

    // handle delete post ajax request
    public function delete($id = null) {
        $postModel = new PostModel();
        $post = $postModel->find($id);
        $postModel->delete($id);
        $imageArray = json_decode($post['image'], true);

        for($i = 0; count($imageArray) > $i; $i++){
            $filename = $imageArray[$i]["filename"];
            unlink('uploads/avatar/' . $filename);
        }

        return $this->response->setJSON([
            'error' => false,
            'message' => 'Successfully deleted post!'
        ]);
    }

    // handle fetch post detail ajax request
    public function detail($id = null) {
        $postModel = new PostModel();
        $post = $postModel->find($id);
        return $this->response->setJSON([
            'error' => false,
            'message' => $post
        ]);
    }
}