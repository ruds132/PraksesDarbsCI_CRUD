<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CRUD App Using CI 4 and Ajax</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body>
  <!-- add new post modal start -->
  <div class="modal fade" id="add_post_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel" >Add New Post</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form action="#" method="POST" enctype="multipart/form-data" id="add_post_form" novalidate></form>

        <script type="text/javascript" src="deps/jquery.min.js"></script>
        <script type="text/javascript" src="deps/underscore.js"></script>
        <script type="text/javascript" src="deps/opt/jsv.js"></script>
        <script type="text/javascript" src="lib/jsonform.js"></script>
        <script type="text/javascript">
          var padodFailinu = [];
          var addImageNames = [];
          var addImageToDelete = [];
          var addImageCounter = 0;

          $.get('/post/addCategories', function(categories) {
            JSONForm.fieldTypes['multiplefileupload'] = {
              template: '<input type="file" multiple id="addFileInput" name="titleimage[]" accept="image/*" />'
            };
            JSONForm.fieldTypes['imageSave'] = {
              template: '<input type="hidden" id="file" name="images[]" />'
            };
            JSONForm.fieldTypes['addImageFileName'] = {
              template: '<input type="hidden" id="addImageFileName" name="addImageFileName" />'
            };
            JSONForm.fieldTypes['addImagesToDelete'] = {
              template: '<input type="hidden" id="addImagesToDelete" name="addImagesToDelete[]" />'
            };

            $('#add_post_form').jsonForm({
              schema: {
                addFormImage: {
                  type: "hidden",
                  id: "addFormImage",
                  name: "addFormImage"
                },
                title: {
                  type: 'string',
                  title: 'Post Title',
                  required: true
                },
                category: {
                  type: 'string',
                  title: 'Post Category',
                  enum: categories.map(category => category.name)
                },
                body: {
                  type: 'string',
                  title: 'Post Body'
                },
                file: {
                  type: 'file',
                  title: 'Post Image'
                },
                closeButon: {
                  id: "close",
                  type: "button",
                  title: "Close"
                },
                addtag: {
                  type: "array",
                  items: 
                  {
                    title: "tag",
                    type: "string"
                  }
                },
                
              },
              form: [
                {
                  type: "section",
                  htmlClass: "modal-body p-5",
                  items: [
                    {
                      key: "addFormImage"
                    },
                    {
                      type: "addImagesToDelete"
                    },
                    {
                      type: "section",
                      htmlClass: "mb-3",
                      items: [
                        {
                          key: "title",
                          fieldHtmlClass: "form-control",
                          htmlClass: "mb-3",
                          id: "title"
                        }
                      ]
                    },
                    {
                      type: "section",
                      htmlClass: "mb-3",
                      items: [
                        {
                          key: "category",
                          fieldHtmlClass: "form-control",
                          id: "category",
                          type: "select",
                        }
                      ]
                    },
                    {
                      type: "section",
                      htmlClass: "mb-3",
                      items: [
                        {
                          key: "body",
                          fieldHtmlClass: "form-control",
                          id: "body"
                        }
                      ]
                    },
                    {
                      type: "section",
                      htmlClass: "mb-3",
                      items: [
                        {
                          key: "addtag",
                          title: "Tags:",
                          type: "array",
                          class: "form-control",
                          items: [
                            {
                              key: "addtag[]",
                              title: "Tag {{idx}}",
                              placeholder: "Enter a tag",
                              htmlClass: "m-3",
                            },
                          ]
                        }
                      ]
                    },
                    {
                      type: "section",
                      htmlClass: "mb-3",
                      items: [
                        {
                          type: "imageSave"
                        },
                        {
                          fieldHtmlClass: "form-control",
                          accept: "image/*",
                          type: "multiplefileupload"
                        },
                        {
                          type: "section",
                          htmlClass: "mb-3 row",
                          id: "addImages"
                        },
                      ]
                    },
                    {
                      type: "section",
                      htmlClass: "modal-footer",
                      items: [
                        {
                          htmlClass: "btn btn-secondary"
                        },
                        {
                          type: "submit",
                          title: "Post",
                          htmlClass: "btn btn-primary",
                          id: "closeAddPost"
                        }
                      ]
                    }
                  ]
                }
              ]
            });
            firstDeleteElement = $('._jsonform-array-deletecurrent');
            firstDeleteElement.addClass('btn-primary');
            firstDeleteElement.html('Delete');
            var addmore = $('._jsonform-array-addmore');
            addmore.children().remove();
            addmore.addClass('btn-primary');
            addmore.html('Add');
            addmore.on('click', function() {
              var deleteCurrent = document.getElementsByClassName('_jsonform-array-deletecurrent');
              deleteCurrent[deleteCurrent.length - 1].classList.add('btn-primary');
              deleteCurrent[deleteCurrent.length - 1].innerHTML = 'Delete';
            });
            var removelast = $('._jsonform-array-deletelast');
            removelast.children().remove();
            removelast.addClass('btn-primary');
            removelast.html('Remove');
            $(document).delegate('.uploadImage', 'click', function(e){
              e.preventDefault();
              this.remove();
            });


            // Add form file upload input on change function
            document.getElementById('addFileInput').addEventListener('change', function(event) {

              var files = event.target.files; 
              const previewContainer = document.getElementById('addImages'); 
              var addFormImages = document.getElementById('file');

              // Add form files to upload
              uploadedFiles = Array.from(files)
              for (var i = 0; i < uploadedFiles.length; i++){
                padodFailinu.push(uploadedFiles[i]);
                //console.log(uploadedFiles[i]);
              }

              // Add form add image preview loop on file upload
              for (let i = 0; i < files.length; i++) {
                const file = files[i];
                //console.log(files[i]);
                if (file.type.startsWith('image/')) {
                    const reader = new FileReader();

                  reader.onload = function(e) {
                    const div = document.createElement('div');
                    div.className = 'col-3';

                    const button = document.createElement('button');
                    button.type = 'button';
                    button.className = 'btn-close float-end';
                    button.setAttribute('aria-label', 'Close');
                    
                    button.addEventListener('click', function() {
                        addImageToDelete.push(file)
                        div.remove();
                    });

                    const img = document.createElement('img');
                    img.src = e.target.result; 
                    img.className = 'img-fluid mt-2 mb-2 img-thumbnail';
                    img.style.width = '150px';

                    const input = document.createElement('input');
                    input.value = file.name;
                    input.type = 'text';
                    input.className = 'form-control addfiletitle';
                    input.id = 'addImageId' + addImageCounter;

                    input.addEventListener('change', function(e){
                      //console.log(e.srcElement.attributes.id.value);
                      //console.log(e);
                      var objectId = e.srcElement.attributes.id.value.charAt(e.srcElement.attributes.id.value.length - 1);
                      if(addImageNames.some(obj => obj.id === objectId)){
                        for(var i = 0; i < addImageNames.length; i++){
                          if(addImageNames[i].id == objectId){
                            addImageNames[i] = {id: objectId, nameChange: e.target.value};
                          }
                        }
                      } else {
                        addImageNames.push({id: objectId, nameChange: e.target.value});
                      }

                    });
                    div.appendChild(button);
                    div.appendChild(img);
                    div.appendChild(input);
                    addImageCounter++;
                    previewContainer.appendChild(div);
                  };
                  reader.readAsDataURL(file);
                }
              }
            });


          });
        </script>
      </div>
    </div>
  </div>
  <!-- add new post modal end -->

  <!-- edit post modal start -->
  <div class="modal fade" id="edit_post_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Edit Post</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        
        <form action="#" method="POST" enctype="multipart/form-data" id="edit_post_form" novalidate></form>

          <script type="text/javascript">
          JSONForm.fieldTypes['multiplefileuploadedit'] = {
            template: '<input type="file" multiple id="editFileInput" name="editimage[]"  />'
          }
          JSONForm.fieldTypes['editToDelete'] = {
            template: '<input type="hidden" id="editToDelete" name="editToDelete[]"  />'
          }
          JSONForm.fieldTypes['editImageFileName'] = {
            template: '<input type="hidden" id="editImageFileName" name="editImageFileName" />'
          };
          var imageNameChange = [];
          var editImageFiles = [];
          var deleteImages = [];
          function dati(data){
            //console.log(data);
            const categoriesOptions = data.categories.map(category => {
              return { value: category.id, title: category.name };
            });
            var displayEditTags = JSON.parse(data.post.tags);
            //(displayEditTags);

            $('#edit_post_form').jsonForm({
              schema: {
                id: {
                  type: "hidden",
                  id: "pid",
                  name: "id"
                },
                title: {
                  type: 'string',
                  title: 'Post Title',
                  required: true
                },
                category: {
                  type: 'string',
                  title: 'Post Category',
                  enum: categoriesOptions.map(option => option.value),
                  required: true
                },
                body: {
                  type: 'string',
                  title: 'Post Body',
                  required: true
                },
                tag: {
                  type: "array",
                  items: 
                  {
                    title: "Tags:",
                    type: "string"
                  }
                },
              },
              value: {
                id: data.post.id,
                title: data.post.title,
                category: data.post.category,
                body: data.post.body,
                tag: displayEditTags
              },
              "form": [
                {
                  type: "section",
                  htmlClass: "modal-body p-5",
                  id: "editFormData",
                  items: [
                    { key: "id" },
                    { type: "editToDelete"},
                    { type: "editImageFileName"},
                    {
                      type: "section",
                      htmlClass: "mb-3",
                      items: [
                        {
                          key: "title",
                          fieldHtmlClass: "form-control",
                          htmlClass: "mb-3",
                        },
                      ]
                    },
                    {
                      type: "section",
                      htmlClass: "mb-3",
                      items: [
                        {
                          key: "category",
                          fieldHtmlClass: "form-control",
                          id: "category",
                          type: "select",
                          options: categoriesOptions
                        }
                      ]
                    },
                    {
                      type: "section",
                      htmlClass: "mb-3",
                      items: [
                        {
                          key: "body",
                          fieldHtmlClass: "form-control",
                          id: "body"
                        }
                      ]  
                    },
                    {
                      type: "section",
                      htmlClass: "mb-3",
                      items: [
                        {
                          key: "tag",
                          class: "form-control",
                          items: [
                            {
                              key: "tag[]",
                              title: "Tag {{idx}}",
                              placeholder: "Enter a tag",
                              htmlClass: "m-3",
                            },
                          ]
                        },
                      ]
                    },
                    {
                      type: "section",
                      htmlClass: "mb-3",
                      items: [
                        {
                          htmlClass: "form-control",
                          multiple: true,
                          accept: "image/*",
                          type: "multiplefileuploadedit"
                        },
                      ]  
                    },
                    {
                      type: "section",
                      htmlClass: "row mb-3 images",
                      id: "images"
                    },
                    {
                      type: "section",
                      htmlClass: "modal-footer",
                      items: [
                        {
                          id: "close",
                          type: "button",
                          title: "Close",
                          htmlClass: "btn btn-secondary"
                        },
                        {
                          type: "submit",
                          title: "Update Post",
                          htmlClass: "btn btn-primary"
                        }
                      ]
                    }
                  ]
                }
              ],
            });
            var closeButton = document.getElementById('close');
            closeButton.setAttribute("data-bs-dismiss", "modal");

            //console.log($('._jsonform-array-addmore'));

            firstDeleteElement = $('._jsonform-array-deletecurrent');
            firstDeleteElement.addClass('btn-primary');
            firstDeleteElement.html('Delete');
            var addmore = $('._jsonform-array-addmore');
            addmore.children().remove();
            addmore.addClass('btn-primary');
            addmore.html('Add');
            addmore.on('click', function() {
              var deleteCurrent = document.getElementsByClassName('_jsonform-array-deletecurrent');
              deleteCurrent[deleteCurrent.length - 1].classList.add('btn-primary');
              deleteCurrent[deleteCurrent.length - 1].innerHTML = 'Delete';
            });
            var removelast = $('._jsonform-array-deletelast');
            removelast.children().remove();
            removelast.addClass('btn-primary');
            removelast.html('Remove');
            let postimage = JSON.parse(data.post['image']);
            //console.log(postimage[0].filename);
            // Edit form add existing image preview
            var imagee = JSON.parse(data.post.image);
            for(var a = 0; a < imagee.length; a++){
              $(".images").append('<div class="col-3 post_image_class"><button type="button" class="btn-close float-end" aria-label="Close"/><img src="<?= base_url('uploads/avatar/') ?>' + postimage[a].filename + '" class="img-fluid mt-2 mb-2 img-thumbnail" width="150"><input type="text" class="form-control filetitle" id="image' + [a] + '" value="' + postimage[a].filetitle + '"></div>');
            }
            // Edit Form image name change
            $('.filetitle').on('change', function(event) {
              var id = this.id
              var found = '';
              whichImage = id.charAt(id.length - 1);

              if(imageNameChange.some(obj => obj.id === whichImage)){
                for(var i = 0; i < imageNameChange.length; i++){
                  if(imageNameChange[i].id == whichImage){
                    imageNameChange[i] = {id: whichImage, nameChange: event.target.value};
                  }
                }
              } else {
                imageNameChange.push({id: whichImage, nameChange: event.target.value});
              }
            });
            // Edit image upload
            document.getElementById('editFileInput').addEventListener('change', function(event) {
            const files = event.target.files; 
            const previewContainer = document.getElementById('images');
            //Send files to backend
            uploadedEditFiles = Array.from(files)
            for (var i = 0; i < uploadedEditFiles.length; i++){
              editImageFiles.push(uploadedEditFiles[i]);
            }
            // Edit form add uploaded file image preview
            for (let i = 0; i < files.length; i++) {
                const file = files[i];
                //console.log(file);
                if (file.type.startsWith('image/')) {
                    const reader = new FileReader();
  
                  reader.onload = function(e) {
                    const div = document.createElement('div');  
                    div.className = 'col-3';

                    const button = document.createElement('button');
                    button.type = 'button';
                    button.className = 'btn-close float-end fresh_post_image_class';
                    button.setAttribute('aria-label', 'Close');
                    
                    button.addEventListener('click', function() {
                        div.remove(); 
                        //console.log("Image container clicked.");
                        deleteImages.push(file);
                        $(this).parent().remove();
                    });

                    const img = document.createElement('img');
                    img.src = e.target.result; 
                    img.className = 'img-fluid mt-2 mb-2 img-thumbnail';
                    img.style.width = '150px';

                    div.appendChild(button);
                    div.appendChild(img);

                    previewContainer.appendChild(div);
                  };
                  reader.readAsDataURL(file);
                }
            }
          });
        }
        </script>
      </div>
    </div>
  </div>
  <!-- edit post modal end -->

  <!-- detail post modal start -->
  <div class="modal fade" id="detail_post_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Details of Post</h5>
          <button type="button" class="btn-close closeDetails" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="post_image_div">
            <img src="" id="detail_post_image" class="img-fluid">
          </div>
          <h3 id="detail_post_title" class="mt-3"></h3>
          <h5 id="detail_post_category"></h5>
          <p id="detail_post_body"></p>
          <p id="detail_post_created" class="fst-italic"></p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary closeDetails" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
  <!-- detail post modal end -->

  <div class="container">
    <div class="row my-4">
      <div class="col-9">
        <div class="card shadow">
          <div class="card-header d-flex justify-content-between align-items-center">
            <div class="text-secondary fw-bold fs-3">All Posts</div>
            <button class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#add_post_modal">Add New Post</button>
          </div>
          <div class="card-body">
            <div class="row" id="show_posts">
              <h1 class="text-center text-secondary my-5">Posts Loading..</h1>
            </div>
          </div>
        </div>
      </div>
      <div class="col-3">
        <h3>Tags</h3> 
        <div id="tags">

        </div>
      </div>
    </div>
  </div>
  <!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script> -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script>
    var myModal = document.getElementById('edit_post_modal');
    myModal.addEventListener('hidden.bs.modal', function () {
      $('#editFormData').remove();
    });
    var visiTags = [];
    var selectedTags = [];
    var disabledTags = [];
    $(function() {
      // add new post ajax request
      $("#add_post_form").submit(async function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        //console.log(padodFailinu);

        // image file titles
        formData.delete("titleimage[]");
        for(var i = 0; i < padodFailinu.length; i++){
          formData.append("titleimage[]", padodFailinu[i]);
        }

        formData.delete("addImageFileName");
        formData.append("addImageFileName", JSON.stringify(addImageNames));

        // deleted images to be removed
        formData.delete('addImagesToDelete[]');
        for(var a = 0; a < addImageToDelete.length; a++){
          formData.append('addImagesToDelete[]', addImageToDelete[a]);
        }

        // selected category
        formData.delete("category");
        await $.get('/post/addCategories', function(categories) {
          const name = $("select[name='category']").val();
          const item = categories.find(obj => obj.name === name);
          formData.append("category", item.id);
        });

        // debugging: outputs every formData entry
        // console.log("FormData contents:");
        // for (let [key, value] of formData.entries()) {
        //   console.log(key, value);
        // }
        if (!this.checkValidity()) {
          e.preventDefault();
          $(this).addClass('was-validated');
        } else {
          $("#add_post_btn").text("Adding...");
          $.ajax({
            url: '<?= base_url('post/add') ?>',
            method: 'post',
            data: formData,
            contentType: false,
            cache: false,
            processData: false,
            dataType: 'json',
            success: function(response) {
              if (response.error) {
                $("#image").addClass('is-invalid');
                $("#image").next().text(response.message.image);
              } else {
                // value reset
                padodFailinu = [];
                addImageNames = [];
                addImageToDelete = [];
                addImageCounter = 0;
                $('#addImages').empty(); 
                $("#add_post_modal").modal('hide');
                $("#add_post_form")[0].reset();
                $("#image").removeClass('is-invalid');
                $("#image").next().text('');
                $("#add_post_form").removeClass('was-validated');
                Swal.fire(
                  'Added',
                  response.message,
                  'success'
                );
                fetchAllPosts();
              }
              $("#add_post_btn").text("Add Post");
            }
          });
        }
      });

      // edit post ajax request
      $(document).delegate('.post_edit_btn', 'click', function(e) {
        e.preventDefault();
        const id = $(this).attr('id');
        $.ajax({
          url: '<?= base_url('post/edit/') ?>/' + id,
          method: 'get',
          success: function(response) {
            dati(response.message);
          }
        });
      });
      // update post ajax request
      $("#edit_post_form").submit(function(e) {
        e.preventDefault();
        const id = $(this).attr('id');
        var formData = new FormData(this);

        formData.delete("editToDelete[]");
        for(var a = 0; a < deleteImages.length; a++){
          formData.append("editToDelete[]", deleteImages[a])
        }

        formData.delete("editimage[]");
        for(var a = 0; a < editImageFiles.length; a++){
          formData.append("editimage[]", editImageFiles[a])
        }

        // debugging: outputs every formData entry
        // console.log("FormData contents:");
        // for (let [key, value] of formData.entries()) {
        //   console.log(key, value);
        // }

        formData.delete("fileNames");
        formData.append("fileNames", JSON.stringify(imageNameChange));
        if (!this.checkValidity()) {
          e.preventDefault();
          $(this).addClass('was-validated');
        } else {
          imageNameChange = [];
          editImageFiles = [];
          deleteImages = [];
          $("#edit_post_btn").text("Updating...");
          $.ajax({
            url: '<?= base_url('post/update') ?>',
            method: 'post',
            data: formData,
            contentType: false,
            cache: false,
            processData: false,
            dataType: 'json',
            success: function(response) {
              $("#edit_post_modal").modal('hide');
              Swal.fire(
                'Updated',
                response.message,
                'success'
              );
              fetchAllPosts();
              $("#edit_post_btn").text("Update Post");
            }
          });
        }
      });

      // delete post ajax request
      $(document).delegate('.post_delete_btn', 'click', function(e) {
        e.preventDefault();
        const id = $(this).attr('id');
        Swal.fire({
          title: 'Are you sure?',
          text: "You won't be able to revert this!",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
          if (result.isConfirmed) {
            $.ajax({
              url: '<?= base_url('post/delete/') ?>/' + id,
              method: 'get',
              success: function(response) {
                Swal.fire(
                  'Deleted!',
                  response.message,
                  'success'
                )
                fetchAllPosts();
              }
            });
          }
        })
      });
      // post detail ajax request
      $(document).delegate('.post_detail_btn', 'click', function(e) {
        e.preventDefault();
        const id = $(this).attr('id');
        $.ajax({
          url: '<?= base_url('post/detail/') ?>/' + id,
          method: 'get',
          dataType: 'json',
          success: function(response) {
            let imagee = JSON.parse(response.message['image']);
            for(var i = 0; i < imagee.length; i++){
              var imgHtmlData = '<img src="uploads/avatar/' + imagee[i].filename + '" id="detail_post_image' + i + '" class="img-fluid">';
              $('#post_image_div').append(imgHtmlData);
            }
            $("#detail_post_title").text(response.message.title);
            $("#detail_post_category").text(response.message.category);
            $("#detail_post_body").text(response.message.body);
            $("#detail_post_created").text(response.message.created_at);
          }
        });
      });
      $(document).on('click', '.closeDetails', function(e){
        e.preventDefault();
        $('#post_image_div').empty();
      });

      fetchAllPosts();
      // fetch all posts ajax request
      function fetchAllPosts() {
        var tagUrl = 'tuksums';
        if(selectedTags.length > 0){
          tagUrl = selectedTags.join();
        }
        $.ajax({
          url: '<?= base_url('post/fetch/') ?>' + tagUrl,
          method: 'get',
          success: function(response) {
            $("#show_posts").html(response.message);
            if(selectedTags.length < 1){
              fetchTags()
            }
          }
        });
      }

      function fetchTags(){
        var tagini = $('#tags');
        $.ajax({
          url: '<?= base_url('tags') ?>',
          method: 'get',
          success: function(response) {
            if (response.error) {
              tagini.html('viss slikti');
            } else {
              visiTags = [];
              tagini.empty();
              for(var o = 0; o < response.message.length; o++){
                visiTags.push(JSON.parse(response.message[o]))
              }
              visiTags.forEach(element => {
                const button = document.createElement('button');
                button.type = 'button';
                button.className = 'btn btn-primary m-1';
                button.innerHTML = element;
                button.addEventListener('click', function(event){
                  selectedTags.push(event.target.innerHTML);
                  event.target.classList.add('active');
                  event.target.setAttribute("aria-pressed", "true");
                  fetchAllPosts();
                });
                tagini.append(button);
              });
            }
          }
        });    
      }
    });
  </script>
</body>
</html>